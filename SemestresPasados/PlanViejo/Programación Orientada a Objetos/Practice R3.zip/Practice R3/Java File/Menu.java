public class Menu {
  public static void main() {
    System.out.println("\n\t1) Cargar lista de alumnos desde un archivo");
    System.out.println("\t2) Cargar lista de profesores desde un archivo");
    System.out.println("\t3) Capturar lista de alumnos manualmente (esto borrara cualquier lista de alumnos capturada)");
    System.out.println("\t4) Capturar lista de profesores manualmente (esto borrara cualquier lista de profesores capturada)");
    System.out.println("\t5) Agregar alumnos a la lista");
    System.out.println("\t6) Agregar profesores a la lista");
    System.out.println("\t7) Guardar lista de alumnos en un archivo");
    System.out.println("\t8) Guardar lista de profesores en un archivo");
    System.out.println("\t9) Imprimir listas");
    System.out.println("\t0) Salir");
  }
}