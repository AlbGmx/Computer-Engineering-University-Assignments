
public class Menu{
	public static void printIt(){
			Print.printStr("\n\n|\t   Datos del Alumno\t\t\t\t|\n");
			Print.printStr("|\t1) Capturar Nombre \t\t\t\t|\n");
			Print.printStr("|\t2) Capturar Solo Nombre\t\t\t\t| \n");
			Print.printStr("|\t3) Capturar Solo Apellido\t\t\t| \n");
			Print.printStr("|\t4) Capturar Nombre de Materia\t\t\t|\n");
			Print.printStr("|\t5) Capturar Calificaciones (0 a 100)\t\t| \n");
			Print.printStr("|\t6) Imprimir Datos Capturados\t\t\t|\n");
			Print.printStr("|\t7) Imprimir Promedio de todas las Calificaciones| \n");
			Print.printStr("|\t0) Salir del programa\t\t\t\t|\n\n");
	}
}