
public class Print{
	public static void printStr(String str){
		System.out.print(str);
	}
	public static void printInt(int num){
		System.out.print(num);
	}
	public static void printFloat(float fnum){
		System.out.print(fnum);
	}
}