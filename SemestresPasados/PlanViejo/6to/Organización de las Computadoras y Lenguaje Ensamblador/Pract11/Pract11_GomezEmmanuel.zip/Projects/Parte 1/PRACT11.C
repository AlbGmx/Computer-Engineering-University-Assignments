#include <stdio.h>
extern void myputchar(char x);
char *str = {"Hola mundo\n"};
void main(void){
    while(*str) myputchar(*str++);
    getchar();
}