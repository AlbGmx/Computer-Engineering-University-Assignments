# uC-Prac1
C review for embedded systems

Please complete the bitwise exercises
